gs <- function(x) {
  msg <- print("", quote = FALSE)
  msg <- print("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx", quote = FALSE, max.levels = 0)
  msg2 <- print((x), quote = FALSE )
  print("", quote = FALSE)

  # strsplit(msg2, "\n")[[1]]
  # https://stackoverflow.com/questions/26022378/r-new-line-in-paste-function
}
